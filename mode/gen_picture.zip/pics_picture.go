package picture

var PixelCount = 58

var Pics = [][]string{
	picture_fire,
	picture_geo,
	picture_honeycorb,
	picture_mario,
	picture_mosaik,
	picture_nyan,
	picture_rainbow,
	picture_simple_cyan,
	picture_star,
	picture_wave,
	picture_weed,
}
